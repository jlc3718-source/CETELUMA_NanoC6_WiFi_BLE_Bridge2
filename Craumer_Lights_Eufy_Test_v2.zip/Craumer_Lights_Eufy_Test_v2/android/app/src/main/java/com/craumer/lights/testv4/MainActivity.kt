package com.craumer.lights.testv4

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(CraumerEufyBridge(), "CraumerEufyBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class CraumerEufyBridge {
        private val io = Executors.newSingleThreadExecutor()
        private val prefs by lazy { getSharedPreferences("eufy_session", MODE_PRIVATE) }

        @JavascriptInterface
        fun request(raw: String): String {
            return try {
                val req = JSONObject(raw)
                val action = req.optString("action")
                val payload = req.optJSONObject("payload") ?: JSONObject()

                val data = when (action) {
                    "connectEufy" -> io.submit<JSONObject> {
                        connectAndDiscover(
                            payload.optString("email"),
                            payload.optString("password")
                        )
                    }.get(30, TimeUnit.SECONDS)

                    "forgetEufy" -> {
                        prefs.edit().clear().apply()
                        JSONObject().put("cleared", true)
                    }

                    "state" -> currentState()
                    "control" -> throw IllegalStateException(
                        "Discovery test only: real T8L00/T8L02 control is enabled after we confirm the protocol."
                    )
                    "settings" -> JSONObject().put("saved", true)
                    "resumeSchedule" -> JSONObject().put("resumed", true)
                    else -> throw IllegalArgumentException("Unknown bridge action: $action")
                }

                JSONObject().put("ok", true).put("data", data).toString()
            } catch (e: Exception) {
                JSONObject()
                    .put("ok", false)
                    .put("error", e.cause?.message ?: e.message ?: "Unknown error")
                    .toString()
            }
        }

        private fun currentState(): JSONObject {
            val connected = prefs.getBoolean("connected", false)
            return JSONObject()
                .put("power", true)
                .put("brightness", 75)
                .put("speed", 3)
                .put("bridgeConnected", connected)
                .put("scheduleWindow", "5:00 PM → 11:00 PM")
                .put("nextEvent", "988 Day • September 8")
                .put("running", JSONObject()
                    .put("name", "Craumer Lights")
                    .put("effect", "Fade")
                    .put("colors", JSONArray(listOf("#14b8a6", "#7e22ce")))
                )
        }

        private fun connectAndDiscover(email: String, password: String): JSONObject {
            require(email.isNotBlank()) { "Email is required." }
            require(password.isNotBlank()) { "Password is required." }

            var token: String? = null
            var authMethod = ""
            val authErrors = mutableListOf<String>()

            // Current Eufy Life-style login first.
            try {
                val body = JSONObject()
                    .put("client_id", "eufy-app")
                    .put("client_secret", "8FHf22gaTKu7MZXqz5zytw")
                    .put("email", email)
                    .put("password", password)

                val response = httpJson(
                    "POST",
                    "https://home-api.eufylife.com/v1/user/v2/email/login",
                    body,
                    eufyHeaders()
                )
                token = findStringRecursive(response, "access_token")
                if (!token.isNullOrBlank()) {
                    authMethod = "Eufy Life v2"
                } else {
                    authErrors += "v2 login: ${safeSummary(response)}"
                }
            } catch (e: Exception) {
                authErrors += "v2: ${e.message}"
            }

            // Legacy EufyHome endpoint fallback.
            if (token.isNullOrBlank()) {
                try {
                    val body = JSONObject()
                        .put("client_id", "eufyhome-app")
                        .put("client_Secret", "GQCpr9dSp3uQpsOMgJ4xQ")
                        .put("email", email)
                        .put("password", password)

                    val response = httpJson(
                        "POST",
                        "https://home-api.eufylife.com/v1/user/email/login",
                        body,
                        eufyHeaders()
                    )
                    token = findStringRecursive(response, "access_token")
                    if (!token.isNullOrBlank()) {
                        authMethod = "EufyHome legacy"
                    } else {
                        authErrors += "legacy login: ${safeSummary(response)}"
                    }
                } catch (e: Exception) {
                    authErrors += "legacy: ${e.message}"
                }
            }

            if (token.isNullOrBlank()) {
                throw IllegalStateException(
                    "Eufy authentication failed. ${authErrors.joinToString(" | ")}"
                )
            }

            prefs.edit()
                .putString("token", token)
                .putBoolean("connected", true)
                .apply()

            val discovered = JSONArray()
            val seen = mutableSetOf<String>()
            val endpointNotes = mutableListOf<String>()

            val endpoints = listOf(
                Pair("https://home-api.eufylife.com/v1/device/v2", emptyMap<String, String>()),
                Pair("https://home-api.eufylife.com/v1/device/", emptyMap<String, String>()),
                Pair(
                    "https://home-api.eufylife.com/v1/device/list/devices-and-groups",
                    mapOf("category" to "Home")
                )
            )

            for ((url, extraHeaders) in endpoints) {
                try {
                    val headers = eufyHeaders().toMutableMap()
                    headers["token"] = token
                    headers.putAll(extraHeaders)
                    val response = httpJson("GET", url, null, headers)
                    val candidates = mutableListOf<JSONObject>()
                    collectObjects(response, candidates)

                    for (obj in candidates) {
                        val model = detectModel(obj)
                        if (model != "T8L00" && model != "T8L02") continue

                        val id = firstNonBlank(
                            obj.optString("id"),
                            obj.optString("device_id"),
                            obj.optString("deviceId"),
                            obj.optString("sn")
                        )

                        val unique = if (id.isNotBlank()) "$model:$id" else "$model:${obj.toString().hashCode()}"
                        if (!seen.add(unique)) continue

                        val name = firstNonBlank(
                            obj.optString("alias_name"),
                            obj.optString("name"),
                            obj.optString("device_name"),
                            obj.optString("deviceName"),
                            "$model light"
                        )

                        val localCode = findStringRecursive(obj, "local_code")
                            ?: findStringRecursive(obj, "localCode")
                            ?: ""

                        val ip = findStringRecursive(obj, "lan_ip_addr")
                            ?: findStringRecursive(obj, "lanIpAddr")
                            ?: findStringRecursive(obj, "ip_addr")
                            ?: findStringRecursive(obj, "ip")
                            ?: ""

                        val portOpen = if (ip.isNotBlank()) probePort(ip, 55556) else null

                        val result = JSONObject()
                            .put("id", id)
                            .put("name", name)
                            .put("model", model)
                            .put("ip", ip)
                            .put("hasLocalCode", localCode.isNotBlank())

                        if (portOpen != null) result.put("port55556", portOpen)
                        discovered.put(result)
                    }
                    endpointNotes += "${URL(url).path}: OK"
                } catch (e: Exception) {
                    endpointNotes += "${URL(url).path}: ${e.message}"
                }
            }

            return JSONObject()
                .put("authMethod", authMethod)
                .put("devices", discovered)
                .put(
                    "notes",
                    "Endpoint checks: ${endpointNotes.joinToString(" • ")}"
                )
        }

        private fun eufyHeaders(): Map<String, String> {
            return mapOf(
                "User-Agent" to "EufyHome-Android-2.4.0",
                "timezone" to "America/New_York",
                "category" to "Home",
                "token" to "",
                "uid" to "",
                "openudid" to "sdk_gphone64_arm64",
                "clientType" to "2",
                "language" to "en",
                "country" to "US",
                "Accept-Encoding" to "gzip"
            )
        }

        private fun safeSummary(obj: JSONObject): String {
            // Show only non-secret diagnostic fields.
            val keys = listOf("res_code", "code", "msg", "message", "error", "status")
            val parts = mutableListOf<String>()
            for (k in keys) {
                if (obj.has(k)) {
                    val v = obj.opt(k)
                    if (v != null && v.toString().isNotBlank() && v.toString() != "null") {
                        parts += "$k=$v"
                    }
                }
            }
            if (parts.isEmpty()) {
                parts += "response keys=${obj.keys().asSequence().toList().joinToString(",")}"
            }
            return parts.joinToString("; ")
        }

        private fun probePort(ip: String, port: Int): Boolean {
            return try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ip, port), 1200)
                    true
                }
            } catch (_: Exception) {
                false
            }
        }

        private fun httpJson(
            method: String,
            urlString: String,
            body: JSONObject?,
            headers: Map<String, String>
        ): JSONObject {
            val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 8000
                readTimeout = 10000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("User-Agent", "Craumer-Lights-Test/0.1")
                for ((k, v) in headers) setRequestProperty(k, v)

                if (body != null) {
                    doOutput = true
                    outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = if (stream != null) {
                BufferedReader(InputStreamReader(stream)).use { it.readText() }
            } else ""

            if (code !in 200..299) {
                val compact = text.replace("\n", " ").take(300)
                throw IllegalStateException("HTTP $code ${if (compact.isBlank()) "" else compact}")
            }

            if (text.isBlank()) return JSONObject()
            return JSONObject(text)
        }

        private fun collectObjects(value: Any?, out: MutableList<JSONObject>) {
            when (value) {
                is JSONObject -> {
                    out += value
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        collectObjects(value.opt(k), out)
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) collectObjects(value.opt(i), out)
                }
            }
        }

        private fun detectModel(obj: JSONObject): String {
            val direct = firstNonBlank(
                obj.optString("product_code"),
                obj.optString("productCode"),
                obj.optString("model"),
                obj.optString("device_model"),
                obj.optString("deviceModel")
            )
            if (direct == "T8L00" || direct == "T8L02") return direct

            val product = obj.optJSONObject("product")
            if (product != null) {
                val nested = firstNonBlank(
                    product.optString("product_code"),
                    product.optString("productCode"),
                    product.optString("model")
                )
                if (nested == "T8L00" || nested == "T8L02") return nested
            }
            return ""
        }

        private fun findStringRecursive(value: Any?, key: String): String? {
            when (value) {
                is JSONObject -> {
                    if (value.has(key)) {
                        val v = value.optString(key)
                        if (v.isNotBlank() && v != "null") return v
                    }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = findStringRecursive(value.opt(keys.next()), key)
                        if (!found.isNullOrBlank()) return found
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) {
                        val found = findStringRecursive(value.opt(i), key)
                        if (!found.isNullOrBlank()) return found
                    }
                }
            }
            return null
        }

        private fun firstNonBlank(vararg values: String): String {
            return values.firstOrNull { it.isNotBlank() && it != "null" } ?: ""
        }
    }
}
