package com.craumer.lights.testv5

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.math.BigInteger
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(CraumerEufyBridge(), "CraumerEufyBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class CraumerEufyBridge {
        private val io = Executors.newSingleThreadExecutor()
        private val prefs by lazy { getSharedPreferences("eufy_session", MODE_PRIVATE) }

        @JavascriptInterface
        fun request(raw: String): String {
            return try {
                val req = JSONObject(raw)
                val action = req.optString("action")
                val payload = req.optJSONObject("payload") ?: JSONObject()

                val data = when (action) {
                    "connectEufy" -> io.submit<JSONObject> {
                        connectAndDiscover(
                            payload.optString("email"),
                            payload.optString("password")
                        )
                    }.get(30, TimeUnit.SECONDS)

                    "forgetEufy" -> {
                        prefs.edit().clear().apply()
                        JSONObject().put("cleared", true)
                    }

                    "state" -> currentState()
                    "control" -> throw IllegalStateException(
                        "Discovery test only: real T8L00/T8L02 control is enabled after we confirm the protocol."
                    )
                    "settings" -> JSONObject().put("saved", true)
                    "resumeSchedule" -> JSONObject().put("resumed", true)
                    else -> throw IllegalArgumentException("Unknown bridge action: $action")
                }

                JSONObject().put("ok", true).put("data", data).toString()
            } catch (e: Exception) {
                JSONObject()
                    .put("ok", false)
                    .put("error", e.cause?.message ?: e.message ?: "Unknown error")
                    .toString()
            }
        }

        private fun currentState(): JSONObject {
            val connected = prefs.getBoolean("connected", false)
            return JSONObject()
                .put("power", true)
                .put("brightness", 75)
                .put("speed", 3)
                .put("bridgeConnected", connected)
                .put("scheduleWindow", "5:00 PM → 11:00 PM")
                .put("nextEvent", "988 Day • September 8")
                .put("running", JSONObject()
                    .put("name", "Craumer Lights")
                    .put("effect", "Fade")
                    .put("colors", JSONArray(listOf("#14b8a6", "#7e22ce")))
                )
        }

        private fun connectAndDiscover(email: String, password: String): JSONObject {
            require(email.isNotBlank()) { "Email is required." }
            require(password.isNotBlank()) { "Password is required." }

            var token: String? = null
            var authMethod = ""
            var authResponse: JSONObject? = null
            val authErrors = mutableListOf<String>()

            // Current Eufy Life-style login first.
            try {
                val body = JSONObject()
                    .put("client_id", "eufy-app")
                    .put("client_secret", "8FHf22gaTKu7MZXqz5zytw")
                    .put("email", email)
                    .put("password", password)

                val response = httpJson(
                    "POST",
                    "https://home-api.eufylife.com/v1/user/v2/email/login",
                    body,
                    eufyHeaders()
                )
                token = findStringRecursive(response, "access_token")
                if (!token.isNullOrBlank()) {
                    authMethod = "Eufy Life v2"
                    authResponse = response
                } else {
                    authErrors += "v2 login: ${safeSummary(response)}"
                }
            } catch (e: Exception) {
                authErrors += "v2: ${e.message}"
            }

            // Legacy EufyHome endpoint fallback.
            if (token.isNullOrBlank()) {
                try {
                    val body = JSONObject()
                        .put("client_id", "eufyhome-app")
                        .put("client_Secret", "GQCpr9dSp3uQpsOMgJ4xQ")
                        .put("email", email)
                        .put("password", password)

                    val response = httpJson(
                        "POST",
                        "https://home-api.eufylife.com/v1/user/email/login",
                        body,
                        eufyHeaders()
                    )
                    token = findStringRecursive(response, "access_token")
                    if (!token.isNullOrBlank()) {
                        authMethod = "EufyHome legacy"
                        authResponse = response
                    } else {
                        authErrors += "legacy login: ${safeSummary(response)}"
                    }
                } catch (e: Exception) {
                    authErrors += "legacy: ${e.message}"
                }
            }

            if (token.isNullOrBlank()) {
                throw IllegalStateException(
                    "Eufy authentication failed. ${authErrors.joinToString(" | ")}"
                )
            }

            prefs.edit()
                .putString("token", token)
                .putBoolean("connected", true)
                .apply()

            // Resolve the Eufy user identity.  The Tuya account used by Eufy is
            // derived from this UID (username = "eh-" + uid).
            var userInfo = findObjectRecursive(authResponse, "user_info")
            var regionalBase = findStringRecursive(authResponse, "request_host")
                ?: "https://home-api.eufylife.com/v1/"

            if (!regionalBase.endsWith("/")) regionalBase += "/"

            if (userInfo == null) {
                try {
                    val headers = eufyHeaders().toMutableMap()
                    headers["token"] = token
                    val infoResponse = httpJson("GET", regionalBase + "user/info", null, headers)
                    userInfo = findObjectRecursive(infoResponse, "user_info")
                        ?: infoResponse.optJSONObject("user_info")
                } catch (_: Exception) {}
            }

            val uid = userInfo?.optString("id").orEmpty().ifBlank {
                findStringRecursive(authResponse, "uid")
                    ?: findStringRecursive(authResponse, "user_id")
                    ?: ""
            }
            val phoneCode = userInfo?.optString("phone_code").orEmpty().ifBlank {
                findStringRecursive(authResponse, "phone_code") ?: "1"
            }

            if (uid.isBlank()) {
                throw IllegalStateException("Eufy authenticated, but no user UID was returned; Tuya discovery cannot start.")
            }

            val discovered = JSONArray()
            val notes = mutableListOf<String>()
            notes += "Eufy authentication: $authMethod"
            notes += "Eufy UID available: yes"
            notes += "Starting Tuya-backed Eufy device discovery…"

            try {
                val tuya = TuyaClient("eh-$uid", phoneCode)
                val session = tuya.acquireSession()
                notes += "Tuya session: connected"
                notes += "Tuya region: ${session.optJSONObject("domain")?.optString("mobileApiUrl") ?: "assigned"}"

                val homes = tuya.listHomes()
                notes += "Tuya homes found: ${homes.length()}"

                for (i in 0 until homes.length()) {
                    val home = homes.optJSONObject(i) ?: continue
                    val groupId = home.optString("groupId")
                    if (groupId.isBlank()) continue

                    val devices = tuya.listDevices(groupId)
                    notes += "Home $groupId devices: ${devices.length()}"

                    for (j in 0 until devices.length()) {
                        val d = devices.optJSONObject(j) ?: continue
                        val result = JSONObject()
                            .put("source", "Tuya")
                            .put("name", firstNonBlank(
                                d.optString("name"),
                                d.optString("devName"),
                                d.optString("productName"),
                                "Unnamed device"
                            ))
                            .put("id", firstNonBlank(
                                d.optString("devId"),
                                d.optString("id"),
                                d.optString("uuid")
                            ))
                            .put("productId", firstNonBlank(
                                d.optString("productId"),
                                d.optString("product_id"),
                                d.optString("pid")
                            ))
                            .put("category", firstNonBlank(
                                d.optString("category"),
                                d.optString("categoryCode"),
                                d.optString("type")
                            ))
                            .put("hasLocalKey", d.optString("localKey").isNotBlank())

                        val model = firstNonBlank(
                            d.optString("model"),
                            d.optString("productCode"),
                            d.optString("product_code"),
                            d.optString("modelCode")
                        )
                        if (model.isNotBlank()) result.put("model", model)

                        val ip = firstNonBlank(
                            d.optString("ip"),
                            d.optString("localIp"),
                            d.optString("lanIp"),
                            d.optString("lan_ip_addr")
                        )
                        if (ip.isNotBlank()) {
                            result.put("ip", ip)
                            result.put("port55556", probePort(ip, 55556))
                            result.put("port6668", probePort(ip, 6668))
                        }

                        // Never return the local key itself to the HTML diagnostics.
                        discovered.put(result)
                    }
                }
            } catch (e: Exception) {
                notes += "Tuya discovery failed: ${e.message}"
            }

            // Also report anything visible through Eufy's own device endpoint as a
            // cross-check.  Do not require a T8L00/T8L02 model string here.
            try {
                val headers = eufyHeaders().toMutableMap()
                headers["token"] = token
                val response = httpJson("GET", regionalBase + "device/v2", null, headers)
                val candidates = mutableListOf<JSONObject>()
                collectObjects(response, candidates)
                var eufyCount = 0
                for (obj in candidates) {
                    val id = firstNonBlank(
                        obj.optString("id"),
                        obj.optString("device_id"),
                        obj.optString("deviceId")
                    )
                    val name = firstNonBlank(
                        obj.optString("alias_name"),
                        obj.optString("name"),
                        obj.optString("device_name")
                    )
                    val model = firstNonBlank(
                        obj.optString("product_code"),
                        obj.optString("productCode"),
                        obj.optString("model")
                    )
                    if (id.isBlank() && name.isBlank() && model.isBlank()) continue
                    if (obj.has("local_code") || obj.has("wifi") || model.startsWith("T8")) {
                        eufyCount++
                    }
                }
                notes += "Eufy device-like records: $eufyCount"
            } catch (e: Exception) {
                notes += "Eufy cross-check failed: ${e.message}"
            }

            return JSONObject()
                .put("authMethod", authMethod)
                .put("devices", discovered)
                .put("notes", notes.joinToString("\n"))

        }

        private fun eufyHeaders(): Map<String, String> {
            return mapOf(
                "User-Agent" to "EufyHome-Android-2.4.0",
                "timezone" to "America/New_York",
                "category" to "Home",
                "token" to "",
                "uid" to "",
                "openudid" to "sdk_gphone64_arm64",
                "clientType" to "2",
                "language" to "en",
                "country" to "US",
                "Accept-Encoding" to "gzip"
            )
        }

        private fun safeSummary(obj: JSONObject): String {
            // Show only non-secret diagnostic fields.
            val keys = listOf("res_code", "code", "msg", "message", "error", "status")
            val parts = mutableListOf<String>()
            for (k in keys) {
                if (obj.has(k)) {
                    val v = obj.opt(k)
                    if (v != null && v.toString().isNotBlank() && v.toString() != "null") {
                        parts += "$k=$v"
                    }
                }
            }
            if (parts.isEmpty()) {
                parts += "response keys=${obj.keys().asSequence().toList().joinToString(",")}"
            }
            return parts.joinToString("; ")
        }

        private fun probePort(ip: String, port: Int): Boolean {
            return try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ip, port), 1200)
                    true
                }
            } catch (_: Exception) {
                false
            }
        }

        private fun httpJson(
            method: String,
            urlString: String,
            body: JSONObject?,
            headers: Map<String, String>
        ): JSONObject {
            val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 8000
                readTimeout = 10000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("User-Agent", "Craumer-Lights-Test/0.1")
                for ((k, v) in headers) setRequestProperty(k, v)

                if (body != null) {
                    doOutput = true
                    outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = if (stream != null) {
                BufferedReader(InputStreamReader(stream)).use { it.readText() }
            } else ""

            if (code !in 200..299) {
                val compact = text.replace("\n", " ").take(300)
                throw IllegalStateException("HTTP $code ${if (compact.isBlank()) "" else compact}")
            }

            if (text.isBlank()) return JSONObject()
            return JSONObject(text)
        }

        private fun collectObjects(value: Any?, out: MutableList<JSONObject>) {
            when (value) {
                is JSONObject -> {
                    out += value
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        collectObjects(value.opt(k), out)
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) collectObjects(value.opt(i), out)
                }
            }
        }

        private fun detectModel(obj: JSONObject): String {
            val direct = firstNonBlank(
                obj.optString("product_code"),
                obj.optString("productCode"),
                obj.optString("model"),
                obj.optString("device_model"),
                obj.optString("deviceModel")
            )
            if (direct == "T8L00" || direct == "T8L02") return direct

            val product = obj.optJSONObject("product")
            if (product != null) {
                val nested = firstNonBlank(
                    product.optString("product_code"),
                    product.optString("productCode"),
                    product.optString("model")
                )
                if (nested == "T8L00" || nested == "T8L02") return nested
            }
            return ""
        }

        private fun findObjectRecursive(value: Any?, key: String): JSONObject? {
            when (value) {
                is JSONObject -> {
                    val direct = value.optJSONObject(key)
                    if (direct != null) return direct
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = findObjectRecursive(value.opt(keys.next()), key)
                        if (found != null) return found
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) {
                        val found = findObjectRecursive(value.opt(i), key)
                        if (found != null) return found
                    }
                }
            }
            return null
        }

        private fun findStringRecursive(value: Any?, key: String): String? {
            when (value) {
                is JSONObject -> {
                    if (value.has(key)) {
                        val v = value.optString(key)
                        if (v.isNotBlank() && v != "null") return v
                    }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = findStringRecursive(value.opt(keys.next()), key)
                        if (!found.isNullOrBlank()) return found
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) {
                        val found = findStringRecursive(value.opt(i), key)
                        if (!found.isNullOrBlank()) return found
                    }
                }
            }
            return null
        }

        private fun firstNonBlank(vararg values: String): String {
            return values.firstOrNull { it.isNotBlank() && it != "null" } ?: ""
        }

        private inner class TuyaClient(
            private val username: String,
            private val countryCode: String
        ) {
            private val clientId = "yx5v9uc3ef9wg3v9atje"
            private val appSecret = "s8x78u7xwymasd9kqa7a73pjhxqsedaj"
            private val bmpSecret = "cepev5pfnhua4dkqkdpmnrdxx378mpjr"
            private val hmacKey = "A_${bmpSecret}_${appSecret}".toByteArray(Charsets.UTF_8)
            private val deviceId = generateDeviceId()
            private var sid: String = ""
            private var baseUrl: String = "https://a1.tuyaeu.com"

            private val aesKey = byteArrayOf(
                36,78,109,-118,86,-84,-121,-111,36,67,45,-117,108,-68,-94,-60
            )
            private val aesIv = byteArrayOf(
                119,36,86,-14,-89,102,76,-13,57,44,53,-105,-23,62,87,71
            )

            fun acquireSession(): JSONObject {
                val tokenResponse = request(
                    action = "tuya.m.user.uid.token.create",
                    version = "1.0",
                    data = JSONObject()
                        .put("uid", username)
                        .put("countryCode", countryCode),
                    requiresSession = false
                ) as? JSONObject ?: throw IllegalStateException("Tuya token response was not an object.")

                val exponent = tokenResponse.optString("exponent").toBigIntegerOrNull()
                    ?: BigInteger.valueOf(tokenResponse.optLong("exponent", 0))
                val modulus = tokenResponse.optString("publicKey").toBigIntegerOrNull()
                    ?: throw IllegalStateException("Tuya public key missing.")
                val challengeToken = tokenResponse.optString("token")
                if (exponent == BigInteger.ZERO || challengeToken.isBlank()) {
                    throw IllegalStateException("Tuya challenge data incomplete.")
                }

                val password = determinePassword(username)
                val encryptedPassword = rsaNoPadding(exponent, modulus, password.toByteArray(Charsets.UTF_8))

                val loginData = JSONObject()
                    .put("uid", username)
                    .put("createGroup", true)
                    .put("ifencrypt", 1)
                    .put("passwd", encryptedPassword.toHex())
                    .put("countryCode", countryCode)
                    .put("options", "{\"group\": 1}")
                    .put("token", challengeToken)

                val session = request(
                    action = "tuya.m.user.uid.password.login.reg",
                    version = "1.0",
                    data = loginData,
                    requiresSession = false
                ) as? JSONObject ?: throw IllegalStateException("Tuya login response was not an object.")

                sid = session.optString("sid")
                val mobileUrl = session.optJSONObject("domain")?.optString("mobileApiUrl").orEmpty()
                if (sid.isBlank()) throw IllegalStateException("Tuya login returned no sid.")
                if (mobileUrl.isNotBlank()) baseUrl = mobileUrl.trimEnd('/')
                return session
            }

            fun listHomes(): JSONArray {
                return request(
                    action = "tuya.m.location.list",
                    version = "2.1",
                    data = null,
                    requiresSession = true
                ) as? JSONArray ?: JSONArray()
            }

            fun listDevices(groupId: String): JSONArray {
                return request(
                    action = "tuya.m.my.group.device.list",
                    version = "1.0",
                    data = null,
                    extraQuery = mapOf("gid" to groupId),
                    requiresSession = true
                ) as? JSONArray ?: JSONArray()
            }

            private fun request(
                action: String,
                version: String = "1.0",
                data: JSONObject? = null,
                extraQuery: Map<String, String> = emptyMap(),
                requiresSession: Boolean = true
            ): Any {
                if (requiresSession && sid.isBlank()) acquireSession()

                val query = linkedMapOf(
                    "appVersion" to "2.4.0",
                    "deviceId" to deviceId,
                    "platform" to "sdk_gphone64_arm64",
                    "clientId" to clientId,
                    "lang" to "en",
                    "osSystem" to "12",
                    "os" to "Android",
                    "timeZoneId" to "America/New_York",
                    "ttid" to "android",
                    "et" to "0.0.1",
                    "sdkVersion" to "3.0.8cAnker",
                    "time" to (System.currentTimeMillis()/1000L).toString(),
                    "requestId" to UUID.randomUUID().toString(),
                    "a" to action,
                    "v" to version
                )
                if (sid.isNotBlank()) query["sid"] = sid
                query.putAll(extraQuery)

                val postData = data?.toString() ?: ""
                val sign = signature(query, postData)

                val fullQuery = query.toMutableMap()
                fullQuery["sign"] = sign
                val queryString = fullQuery.entries.joinToString("&") {
                    "${urlEncode(it.key)}=${urlEncode(it.value)}"
                }

                val conn = (URL("$baseUrl/api.json?$queryString").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 15000
                    setRequestProperty("User-Agent", "TY-UA=APP/Android/2.4.0/SDK/null")
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    doOutput = true
                }

                val body = if (postData.isNotEmpty()) "postData=${urlEncode(postData)}" else ""
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = if (stream != null) BufferedReader(InputStreamReader(stream)).use { it.readText() } else ""

                if (code !in 200..299) {
                    throw IllegalStateException("Tuya HTTP $code ${text.take(240)}")
                }

                val payload = JSONObject(text)
                if (!payload.has("result")) {
                    val errorCode = payload.optString("errorCode")
                    throw IllegalStateException("Tuya API error ${if(errorCode.isBlank()) "" else "[$errorCode] "}${safeSummary(payload)}")
                }
                return payload.get("result")
            }

            private fun signature(query: Map<String, String>, postData: String): String {
                val relevant = setOf(
                    "a","v","lat","lon","lang","deviceId","appVersion","ttid","isH5",
                    "h5Token","os","clientId","postData","time","requestId","et","n4h5",
                    "sid","sp"
                )

                val pairs = mutableMapOf<String, String>()
                pairs.putAll(query)
                if (postData.isNotEmpty()) pairs["postData"] = postData

                val message = pairs.entries
                    .filter { it.key.isNotBlank() && relevant.contains(it.key) }
                    .sortedBy { it.key }
                    .joinToString("||") {
                        val value = if (it.key == "postData") shuffledMd5(it.value) else it.value
                        "${it.key}=$value"
                    }

                val mac = Mac.getInstance("HmacSHA256")
                mac.init(SecretKeySpec(hmacKey, "HmacSHA256"))
                return mac.doFinal(message.toByteArray(Charsets.UTF_8)).toHex()
            }

            private fun shuffledMd5(value: String): String {
                val raw = md5Hex(value.toByteArray(Charsets.UTF_8))
                return raw.substring(8,16) + raw.substring(0,8) +
                    raw.substring(24,32) + raw.substring(16,24)
            }

            private fun determinePassword(uid: String): String {
                val paddedSize = ((uid.length + 15) / 16) * 16
                val padded = uid.padStart(paddedSize, '0')
                val cipher = Cipher.getInstance("AES/CBC/NoPadding")
                cipher.init(
                    Cipher.ENCRYPT_MODE,
                    SecretKeySpec(aesKey, "AES"),
                    IvParameterSpec(aesIv)
                )
                val encrypted = cipher.doFinal(padded.toByteArray(Charsets.UTF_8))
                return md5Hex(encrypted.toHex().uppercase().toByteArray(Charsets.UTF_8))
            }

            private fun rsaNoPadding(e: BigInteger, n: BigInteger, plain: ByteArray): ByteArray {
                val keyLength = (n.bitLength() + 7) / 8
                val input = BigInteger(1, plain)
                val out = input.modPow(e, n).toByteArray()
                val unsigned = if (out.size > 1 && out[0].toInt() == 0) out.copyOfRange(1, out.size) else out
                return if (unsigned.size >= keyLength) unsigned.takeLast(keyLength).toByteArray()
                else ByteArray(keyLength - unsigned.size) + unsigned
            }

            private fun generateDeviceId(): String {
                val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                val prefix = "8534c8ec0ed0"
                val rest = buildString {
                    repeat(44 - prefix.length) {
                        append(chars.random())
                    }
                }
                return prefix + rest
            }

            private fun md5Hex(bytes: ByteArray): String =
                MessageDigest.getInstance("MD5").digest(bytes).toHex()

            private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

            private fun urlEncode(s: String): String =
                URLEncoder.encode(s, "UTF-8").replace("+", "%20")
        }
    }
}
