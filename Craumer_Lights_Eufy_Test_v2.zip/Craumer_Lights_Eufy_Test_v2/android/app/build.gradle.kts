plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.craumer.lights.testv5"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.craumer.lights.testv5"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
