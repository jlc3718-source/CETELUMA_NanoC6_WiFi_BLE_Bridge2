# Craumer Lights — Eufy/Tuya Discovery Test v5

v4 proved the Eufy account can authenticate successfully.

v5 follows the architecture used by reverse-engineered EufyHome tooling:
1. Authenticate to Eufy.
2. Read the Eufy user UID and phone/country code.
3. Derive the linked Tuya username (`eh-<uid>`).
4. Perform the Tuya RSA challenge/session login.
5. Enumerate Tuya homes.
6. Enumerate every device in each home.
7. Display device name, device ID, product ID/category, and whether a local key exists.
8. If a LAN IP is returned, probe ports 55556 and 6668.

The app deliberately does not display or export local keys.
No lighting command is sent in v5; discovery only.
