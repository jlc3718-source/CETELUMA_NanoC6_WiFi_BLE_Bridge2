# Craumer Lights — Eufy Discovery Test v2

Target devices:
- 2 × eufy E120 / T8L00
- 2 × eufy E22 / T8L02

This is the first real connectivity test.

## What this build tests
1. Sign in to Eufy Life from the Android app.
2. Try both the newer Eufy Life v2 login and legacy EufyHome login.
3. Query multiple known device-list endpoints.
4. Detect T8L00 and T8L02 devices.
5. Extract LAN IP presence and whether a local_code is supplied.
6. Probe TCP port 55556 on each light controller.

The password is not persisted. Only the returned session token is stored in the app's private SharedPreferences until "Forget Session" is pressed.

## Important
This v2 build does NOT yet send lighting control packets. The point is to identify whether these four models expose the older local Eufy LAN protocol. If port 55556 is open and a local code is returned, we can implement local control next. If not, we will move to the current cloud/Tuya command path instead.
