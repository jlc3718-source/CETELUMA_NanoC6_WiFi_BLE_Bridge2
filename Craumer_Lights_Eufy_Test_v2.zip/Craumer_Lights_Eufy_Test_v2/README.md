# Craumer Lights — Expanded Eufy/Tuya Discovery Test v6

v5 authenticated successfully and found only two vacuum devices. v6 broadens
enumeration instead of attempting control.

v6 now checks:
- every Tuya home returned by the account
- primary home device lists
- alternate versions of group-device list
- account-level device list routes
- device-ref routes
- shared-device routes
- additional safe metadata for identification

The goal is to locate the four Eufy permanent-light controllers without sending
any commands to vacuums, cameras, scale, or other devices.
