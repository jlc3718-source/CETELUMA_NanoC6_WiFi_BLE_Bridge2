# Craumer Lights — Eufy Discovery Test v3

This build corrects the authentication request used in v2.

The prior test reached Eufy's servers but got a JSON response without an access token.
Current working EufyHome/Tuya integrations send a full set of mobile-app headers in
addition to the email/password payload. v3 adds those headers:

- User-Agent: EufyHome-Android-2.4.0
- timezone
- category: Home
- token / uid placeholders
- openudid
- clientType: 2
- language: en
- country: US

It also reports the safe Eufy server error fields (`res_code`, `code`, `msg`, `message`,
`error`, `status`) if authentication still fails.

If login succeeds, the app continues to search specifically for:
- 2 × T8L00
- 2 × T8L02

and tests whether each exposes local LAN information / TCP 55556.
