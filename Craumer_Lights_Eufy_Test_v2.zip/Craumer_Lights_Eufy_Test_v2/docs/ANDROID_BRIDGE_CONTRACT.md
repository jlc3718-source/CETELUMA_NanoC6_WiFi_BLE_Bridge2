# CraumerEufyBridge contract

The WebView injects a JavaScript interface named `CraumerEufyBridge`.

## Request
HTML calls:

`CraumerEufyBridge.request(JSON.stringify({ action, payload }))`

## Response
Return JSON text:

`{"ok":true,"data":{...}}`

or

`{"ok":false,"error":"message"}`

## Actions used by v1
- `state`
- `control`
- `resumeSchedule`
- `settings`

### control payload
Includes `target`:
- `all`
- `e120a`
- `e120b`
- `e22a`
- `e22b`

May include:
- `power`
- `brightness`
- `speed`
- `name`
- `colors`
- `effect`

The native layer is responsible for translating these generic commands into eufy-compatible operations.
