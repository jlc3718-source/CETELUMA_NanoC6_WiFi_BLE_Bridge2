# Anderson Home Light Controller

Complete project source for the M5Stack NanoC6 / ESP32-C6 Wi-Fi-to-Bluetooth light bridge and the lightweight Android wrapper.

## What is included

- Final tabbed Anderson Home web interface:
  - Home with animated mini-house showing the **currently running** effect
  - Lights with single-row preview, colors, brightness, effects and real speed control
  - Events with monthly event list, schedule checkbox and separate ★ favorite checkbox
  - Wi-Fi tab that changes the NanoC6's own Wi-Fi network
  - Settings with overlap rules, schedule times, timezone and BLE setup
- Automatic holiday / public-awareness scheduling
- Overlap modes: rotate nightly, split the night, combine colors
- Persistent settings in ESP32 Preferences
- Wi-Fi recovery hotspot: `AndersonHome-Setup` / password `andersonhome`
- mDNS host: `http://anderson-home.local/`
- BLE scanning and selectable protocol profile
- LEDBLE / FFE0-FFE1 bridge implementation
- Wokwi mock-BLE build
- Android WebView wrapper with mDNS discovery and setup fallback
- GitHub Actions build that produces:
  - `firmware.bin`
  - Android debug APK

## Hardware target

M5Stack NanoC6 (ESP32-C6FH4, 4 MB flash). The official M5Stack PlatformIO configuration uses the ESP32-C6 devkit target with Arduino USB flags.

## BLE compatibility

The firmware targets the common LED BLE family that exposes service `FFE0` and write characteristic `FFE1`. It implements three profiles:

1. LEDBLE / `7E ... EF`
2. RGBIC/SPI / `7B ... BF`
3. RGBIC/SPI shifted opcode variant

On first hardware test, use **Settings → Bluetooth Light Controller → Scan**, select the existing controller, then press **Test Red** and **Test Rainbow**. If Red works but Rainbow does not match, switch the protocol profile and retry.

Because rebadged controllers can use different effect tables, the firmware deliberately keeps the protocol selectable. Power, solid RGB, brightness and speed use the documented LEDBLE command family; dynamic effects use built-in SPI modes when available and a safe firmware-driven fallback otherwise.

## Build firmware

Install PlatformIO, then:

```bash
cd firmware
pio run -e m5stack-nanoc6
```

Output:

`firmware/.pio/build/m5stack-nanoc6/firmware.bin`

## Wokwi

```bash
cd firmware
pio run -e wokwi
```

BLE is mocked in the Wokwi environment, so the web server/scheduling code can be exercised without real BLE hardware.

## Build Android app

The GitHub workflow builds the APK automatically. Locally, with Android SDK and Gradle installed:

```bash
gradle -p android assembleDebug
```

APK:

`android/app/build/outputs/apk/debug/app-debug.apk`

The app first tries `http://anderson-home.local/`, then uses Android network-service discovery. The **Setup** button opens `http://192.168.4.1/` for recovery-hotspot setup.

## First real-hardware commissioning

1. Flash `firmware.bin` to NanoC6.
2. If no Wi-Fi is saved, join `AndersonHome-Setup` using password `andersonhome`.
3. Open `http://192.168.4.1/`.
4. Wi-Fi → scan → select home 2.4 GHz network → enter password → Save & Reconnect.
5. Reopen `http://anderson-home.local/`.
6. Settings → Bluetooth Light Controller → Scan.
7. Select the existing light controller.
8. Run Test Red.
9. Run Test Rainbow.
10. If needed, try the alternate protocol profile.
11. Enable/disable events and mark favorites.
12. Resume Schedule.

## Important hardware-validation point

The software project is complete, but the exact rebadged light-controller BLE dialect cannot be proven without the physical controller. The first Red/Rainbow test is the final commissioning step. The UI, scheduling, Wi-Fi recovery, persistence and Android wrapper do not depend on that protocol mapping.
