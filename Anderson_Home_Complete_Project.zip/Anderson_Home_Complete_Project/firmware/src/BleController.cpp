#include "BleController.h"
#include <math.h>

static uint8_t r8(uint32_t c){return (c>>16)&0xFF;} static uint8_t g8(uint32_t c){return (c>>8)&0xFF;} static uint8_t b8(uint32_t c){return c&0xFF;}
static uint32_t hsv(float h,float s,float v){h=fmodf(h,360.0f);float c=v*s,x=c*(1-fabsf(fmodf(h/60.0f,2)-1)),m=v-c;float r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}return ((uint32_t)((r+m)*255)<<16)|((uint32_t)((g+m)*255)<<8)|(uint32_t)((b+m)*255);}

void BleController::begin(AppSettings* settings){
  cfg=settings;protocol=cfg->bleProtocol;
#ifdef MOCK_BLE
  deviceName="Wokwi Mock LEDBLE";deviceAddress="MOCK";
#else
  NimBLEDevice::init("AndersonHome-Bridge");
  NimBLEDevice::setPower(3);
  if(cfg->bleAddress.length()) connectAddress(cfg->bleAddress);
  else {
    auto found=scan(3000);
    if(!found.empty()) selectAndConnect(found[0].address,cfg->bleProtocol);
  }
#endif
}
bool BleController::connected() const{
#ifdef MOCK_BLE
  return true;
#else
  return client && client->isConnected() && chr;
#endif
}
String BleController::protocolName() const{uint8_t p=protocol;if(p==0)p=detectProtocol(deviceName);if(p==1)return "LEDBLE A";if(p==2)return "RGBIC B";if(p==3)return "RGBIC B shifted";return "Auto";}
uint8_t BleController::detectProtocol(const String& n) const{String u=n;u.toUpperCase();if(u.startsWith("LEDCAR-02")||u.startsWith("LEDDMX-02")||u.startsWith("LEDDMX-04"))return 3;if(u.startsWith("LEDCAR-01")||u.startsWith("LEDDMX"))return 2;return 1;}

std::vector<BleFound> BleController::scan(uint32_t ms){
  std::vector<BleFound> out;
#ifdef MOCK_BLE
  out.push_back({"Wokwi Mock LEDBLE","MOCK",-42});return out;
#else
  NimBLEScan* sc=NimBLEDevice::getScan();sc->setActiveScan(true);sc->setInterval(90);sc->setWindow(60);sc->start(ms,false);NimBLEScanResults results=sc->getResults();
  for(int i=0;i<results.getCount();i++){const NimBLEAdvertisedDevice* d=results.getDevice(i);String n=d->getName().c_str();String u=n;u.toUpperCase();if(u.indexOf("LED")>=0 || u.indexOf("RGB")>=0){out.push_back({n,String(d->getAddress().toString().c_str()),d->getRSSI()});}}
  std::sort(out.begin(),out.end(),[](const BleFound&a,const BleFound&b){return a.rssi>b.rssi;});sc->clearResults();return out;
#endif
}
bool BleController::selectAndConnect(const String& addr,uint8_t p){protocol=p;if(cfg){cfg->bleAddress=addr;cfg->bleProtocol=p;}return connectAddress(addr);}
bool BleController::connectAddress(const String& addr){
#ifdef MOCK_BLE
  deviceAddress=addr;deviceName="Wokwi Mock LEDBLE";return true;
#else
  disconnect(); NimBLEAddress a(addr.c_str()); client=NimBLEDevice::createClient(); if(!client->connect(a)){NimBLEDevice::deleteClient(client);client=nullptr;return false;}
  NimBLERemoteService* svc=client->getService("FFE0"); if(!svc){disconnect();return false;} chr=svc->getCharacteristic("FFE1"); if(!chr){disconnect();return false;}
  deviceAddress=addr;deviceName=client->getPeerAddress().toString().c_str(); return true;
#endif
}
void BleController::disconnect(){
#ifndef MOCK_BLE
  chr=nullptr;if(client){if(client->isConnected())client->disconnect();NimBLEDevice::deleteClient(client);client=nullptr;}
#endif
}
bool BleController::writeFrame(const uint8_t* data,size_t len){
  if(millis()-lastWrite<35)delay(35-(millis()-lastWrite));lastWrite=millis();
#ifdef MOCK_BLE
  Serial.print("[MOCK BLE] ");for(size_t i=0;i<len;i++)Serial.printf("%02X ",data[i]);Serial.println();return true;
#else
  if(!connected())return false;return chr->writeValue(data,len,true);
#endif
}
void BleController::setPower(bool on){uint8_t p=protocol?protocol:detectProtocol(deviceName);uint8_t f[9];if(p==1){uint8_t x[9]={0x7E,0xFF,0x04,(uint8_t)(on?1:0),0xFF,0xFF,0xFF,0xFF,0xEF};memcpy(f,x,9);}else if(p==2){uint8_t x[9]={0x7B,0xFF,0x04,(uint8_t)(on?1:0),0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}else{uint8_t x[9]={0x7B,0x04,(uint8_t)(on?1:0),0xFF,0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}writeFrame(f,9);}
void BleController::setColor(uint32_t c){uint8_t p=protocol?protocol:detectProtocol(deviceName),R=r8(c),G=g8(c),B=b8(c);uint8_t f[9];if(p==1){uint8_t x[9]={0x7E,0xFF,0x05,0x03,R,G,B,0xFF,0xEF};memcpy(f,x,9);}else if(p==2){uint8_t x[9]={0x7B,0xFF,0x07,R,G,B,0x00,0xFF,0xBF};memcpy(f,x,9);}else{uint8_t x[9]={0x7B,0x07,R,G,B,0x00,0xFF,0xFF,0xBF};memcpy(f,x,9);}writeFrame(f,9);}
void BleController::setBrightness(uint8_t B){B=constrain(B,0,100);uint8_t p=protocol?protocol:detectProtocol(deviceName);uint8_t f[9];if(p==1){uint8_t x[9]={0x7E,0xFF,0x01,B,0x00,0xFF,0xFF,0xFF,0xEF};memcpy(f,x,9);}else if(p==2){uint8_t x[9]={0x7B,0xFF,0x01,(uint8_t)(B*32/100),B,0x01,0xFF,0xFF,0xBF};memcpy(f,x,9);}else{uint8_t x[9]={0x7B,0x01,B,0x00,0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}writeFrame(f,9);}
void BleController::setSpeed(uint8_t S){S=constrain(S,0,100);uint8_t p=protocol?protocol:detectProtocol(deviceName);uint8_t f[9];if(p==1){uint8_t x[9]={0x7E,0xFF,0x02,S,0x00,0xFF,0xFF,0xFF,0xEF};memcpy(f,x,9);}else if(p==2){uint8_t x[9]={0x7B,0xFF,0x02,S,0x00,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}else{uint8_t x[9]={0x7B,0x02,S,0x00,0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}writeFrame(f,9);}
void BleController::setMode(uint8_t M){uint8_t p=protocol?protocol:detectProtocol(deviceName);uint8_t f[9];if(p==1){uint8_t x[9]={0x7E,0xFF,0x03,M,0x03,0xFF,0xFF,0xFF,0xEF};memcpy(f,x,9);}else if(p==2){uint8_t x[9]={0x7B,0xFF,0x03,M,0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}else{uint8_t x[9]={0x7B,0x03,M,0xFF,0xFF,0xFF,0xFF,0xFF,0xBF};memcpy(f,x,9);}writeFrame(f,9);}

void BleController::applyTheme(const Theme& t,uint8_t bright,uint8_t speedLevel,uint32_t nowMs,bool force){
  uint8_t p=protocol?protocol:detectProtocol(deviceName);uint8_t sp=map(constrain(speedLevel,1,5),1,5,20,95);
  bool changed=!activeValid || activeTheme.name!=t.name || activeTheme.effect!=t.effect;
  if(force||changed){activeTheme=t;activeValid=true;setPower(true);setBrightness(bright);setSpeed(sp);}
  if(t.effect==Effect::Solid){if(force||changed)setColor(t.colors[0]);return;}
  if(p>=2 && (t.effect==Effect::Rainbow||t.effect==Effect::Chase||t.effect==Effect::Meteor)){
    if(force||changed){uint8_t mode=t.effect==Effect::Rainbow?3:(t.effect==Effect::Chase?39:23);setMode(mode);}return;
  }
  uint32_t interval=map(constrain(speedLevel,1,5),1,5,650,90);if(!force && nowMs-lastEffect<interval)return;lastEffect=nowMs;
  float phase=(nowMs%(interval*40))/(float)(interval*40);uint32_t color=t.colors[0];uint8_t b=bright;
  if(t.effect==Effect::Fade){int idx=(int)(phase*t.colorCount)%t.colorCount;int nxt=(idx+1)%t.colorCount;float f=fmodf(phase*t.colorCount,1.0f);uint32_t a=t.colors[idx],z=t.colors[nxt];uint8_t R=r8(a)+(r8(z)-r8(a))*f,G=g8(a)+(g8(z)-g8(a))*f,B=b8(a)+(b8(z)-b8(a))*f;color=((uint32_t)R<<16)|((uint32_t)G<<8)|B;}
  else if(t.effect==Effect::Pulse){b=(uint8_t)(bright*(0.25f+0.75f*(0.5f+0.5f*sinf(phase*2*PI))));}
  else if(t.effect==Effect::Rainbow){color=hsv(phase*360,1,1);}
  else if(t.effect==Effect::Twinkle){color=t.colors[random(t.colorCount)];b=random(35,bright+1);}
  else if(t.effect==Effect::CandyCane){color=t.colors[((nowMs/interval)%max(1,(int)t.colorCount))];}
  else if(t.effect==Effect::Fire){color=((uint32_t)255<<16)|((uint32_t)random(40,170)<<8);}
  else if(t.effect==Effect::Water){color=((uint32_t)0<<16)|((uint32_t)random(90,200)<<8)|255;}
  else {color=t.colors[((nowMs/interval)%max(1,(int)t.colorCount))];}
  setColor(color);setBrightness(b);
}
void BleController::loop(){
#ifndef MOCK_BLE
  static uint32_t retry=0;if(!connected() && cfg && millis()-retry>30000){retry=millis();if(cfg->bleAddress.length())connectAddress(cfg->bleAddress);}
#endif
}
