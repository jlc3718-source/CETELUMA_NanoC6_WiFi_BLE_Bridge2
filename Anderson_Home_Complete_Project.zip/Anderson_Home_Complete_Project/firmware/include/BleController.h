#pragma once
#include <Arduino.h>
#include <vector>
#include "Types.h"
#ifndef MOCK_BLE
#include <NimBLEDevice.h>
#endif

struct BleFound { String name; String address; int rssi; };

class BleController {
 public:
  void begin(AppSettings* settings);
  void loop();
  bool connected() const;
  String name() const { return deviceName; }
  String address() const { return deviceAddress; }
  String protocolName() const;
  std::vector<BleFound> scan(uint32_t ms=3500);
  bool selectAndConnect(const String& address,uint8_t protocol);
  void disconnect();
  void setPower(bool on);
  void setBrightness(uint8_t pct);
  void setSpeed(uint8_t pct);
  void setColor(uint32_t rgb);
  void setMode(uint8_t mode);
  void applyTheme(const Theme& theme,uint8_t brightness,uint8_t speedLevel,uint32_t nowMs,bool force=false);
 private:
  AppSettings* cfg=nullptr;
  String deviceName,deviceAddress;
  uint8_t protocol=0;
  uint32_t lastWrite=0,lastEffect=0;
  Theme activeTheme;
  bool activeValid=false;
#ifndef MOCK_BLE
  NimBLEClient* client=nullptr;
  NimBLERemoteCharacteristic* chr=nullptr;
#endif
  bool connectAddress(const String& address);
  uint8_t detectProtocol(const String& n) const;
  bool writeFrame(const uint8_t* data,size_t len);
  void dynamicFrame(const Theme& t,uint8_t brightness,uint8_t speedLevel,uint32_t nowMs);
};
