#pragma once
#include <Arduino.h>

static const char WEB_UI[] PROGMEM = R"ANDERSONHTML(
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0b0e13">
<title>Anderson Home Lights</title>
<style>
:root{--bg:#0b0e13;--panel:#151a22;--card:#10151c;--line:#2a3340;--text:#f4f7fb;--muted:#9aa6b5;--accent:#27aaff;--accentbg:#18334a;--good:#38d486;--warn:#ffb020}
*{box-sizing:border-box} body{margin:0;background:linear-gradient(180deg,#090c11,#111722);color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
.wrap{max-width:720px;margin:0 auto;padding:14px 12px 30px}.header{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}
h1{font-size:22px;margin:0}.sub,.muted{color:var(--muted)}.sub{font-size:12px}.badge{font-size:12px;color:var(--good);background:#0b2a1a;border:1px solid #1f6742;padding:6px 9px;border-radius:999px;white-space:nowrap}
.badge.offline{color:#ffcb6b;background:#2c210b;border-color:#654d1d}.nav{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;margin-bottom:12px}
button,select,input{font:inherit}.tab,.btn,.field{border:1px solid var(--line);background:var(--card);color:var(--text);border-radius:12px;min-height:44px;padding:9px 10px}
.tab{font-size:12px}.tab.active{border-color:var(--accent);background:var(--accentbg)}.btn{cursor:pointer}.btn.primary{background:linear-gradient(180deg,#27aaff,#148de1);border-color:#3bb2ff;font-weight:700}.btn.danger{border-color:#794040;color:#ffcaca}
.field{width:100%;font-size:16px}.page{display:none}.page.active{display:block}.panel{background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:14px;margin:11px 0}.card{background:var(--card);border:1px solid var(--line);border-radius:15px;padding:12px}
.row{display:flex;gap:10px;align-items:center}.between{justify-content:space-between}.wraprow{flex-wrap:wrap}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:9px}.label{font-size:13px;margin:11px 0 6px}
input[type=checkbox]{width:22px;height:22px;accent-color:var(--accent)}input[type=range]{width:100%;accent-color:var(--accent)}input[type=color]{width:100%;height:46px;border:0;background:transparent}
.quick{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}
.colorBuilder{display:grid;gap:8px;margin-top:8px}
.colorSlot{display:grid;grid-template-columns:48px 1fr auto auto;gap:8px;align-items:center}
.colorSlot input[type=color]{width:48px;height:44px;padding:0}
.colorSlot .slotName{font-size:13px;color:var(--muted)}
.colorSlot .moveBtn,.colorSlot .removeBtn{min-width:44px;padding:8px}
.colorActions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.swatch{aspect-ratio:1;border-radius:11px;border:2px solid rgba(255,255,255,.12);min-height:0;padding:0}
.ledrows{display:block;overflow:hidden}.ledgrid{display:grid;grid-template-columns:repeat(20,minmax(0,1fr));gap:5px}.led{aspect-ratio:1;border-radius:50%;background:#2a313b}
.event{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:start}.eventchecks{display:grid;gap:9px}.chips{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.chip{width:17px;height:17px;border-radius:50%;border:1px solid rgba(255,255,255,.25)}
.small{font-size:12px}.status{font-size:13px;color:var(--muted);margin-top:10px;min-height:18px}.presetList{display:grid;gap:8px;margin-top:10px}.presetRow{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center}
.favoriteGrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:10px}.emptyFav{font-size:12px;color:var(--muted);padding:10px;border:1px dashed var(--line);border-radius:12px}
.housePreview{margin-top:10px;border:1px solid var(--line);background:radial-gradient(circle at 50% 42%,rgba(70,110,150,.12),transparent 52%),linear-gradient(180deg,#0b1017,#0a0e13);border-radius:14px;padding:8px;overflow:hidden}
.housePreview svg{width:100%;height:auto;display:block}.houseOutline{fill:none;stroke:#66717e;stroke-width:3;opacity:.72}.houseDoor{fill:none;stroke:#66717e;stroke-width:2.5;opacity:.55}.houseLed{stroke:rgba(255,255,255,.4);stroke-width:.6}
.monthHead{display:grid;grid-template-columns:1fr .7fr;gap:8px;margin-top:10px}.monthActions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:9px}.note{font-size:12px;line-height:1.45;color:#aeb8c5;background:#10151c;border:1px solid #293441;border-radius:12px;padding:10px;margin-top:10px}
.tags{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.tag{font-size:10px;border:1px solid #3a4654;border-radius:999px;padding:3px 6px;color:#b8c3cf}.tag.holiday{border-color:#385979;color:#9fd2ff}.tag.awareness{border-color:#5b4b83;color:#c9b9f6}.tag.seasonal{border-color:#7a5f36;color:#f4c879}
.bleList{display:grid;gap:8px;margin-top:10px}.bleDevice{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}
@media(max-width:430px){.nav{gap:5px}.tab{padding:8px 4px;font-size:11px}.grid2,.monthHead{grid-template-columns:1fr}.event{grid-template-columns:auto 1fr}.event .previewEvent{grid-column:2}.presetRow{grid-template-columns:1fr}.presetRow .presetApply{grid-column:1}.favoriteGrid{grid-template-columns:1fr 1fr}}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div><h1>Anderson Home</h1><div class="sub">NanoC6 Light Controller</div></div>
    <div id="connectionBadge" class="badge offline">● Preview</div>
  </div>

  <div class="nav" role="tablist">
    <button class="tab active" data-tab="home">Home</button>
    <button class="tab" data-tab="lights">Lights</button>
    <button class="tab" data-tab="events">Events</button>
    <button class="tab" data-tab="wifi">Wi-Fi</button>
    <button class="tab" data-tab="settings">Settings</button>
  </div>

  <section class="page active" data-page="home">
    <div class="panel">
      <div class="row between">
        <div><strong>Lights</strong><div class="sub">Master control</div></div>
        <label class="row"><input id="masterPower" type="checkbox" checked><span class="small">On</span></label>
      </div>
      <div class="label row between"><span>Brightness</span><span id="homeBrightVal" class="muted">75%</span></div>
      <input id="homeBrightness" type="range" min="1" max="100" value="75">
    </div>

    <div class="panel">
      <div class="row between wraprow">
        <div><strong>Running Tonight</strong><div id="nowTheme" class="small" style="margin-top:4px">Loading…</div><div id="scheduleWindow" class="sub">Scheduled 5:00 PM – 11:00 PM</div></div>
        <button id="resumeSchedule" class="btn">Resume Schedule</button>
      </div>
      <div class="housePreview">
        <svg viewBox="0 0 360 182" role="img" aria-label="Mini house showing the currently running light effect">
          <path class="houseOutline" d="M55 82 L180 22 L305 82"/><path class="houseOutline" d="M75 79 L75 145 L285 145 L285 79"/>
          <path class="houseDoor" d="M160 145 L160 105 L200 105 L200 145"/><rect x="95" y="100" width="38" height="26" rx="2" class="houseDoor"/><rect x="227" y="100" width="38" height="26" rx="2" class="houseDoor"/>
          <g id="houseLeds"></g><text x="180" y="172" text-anchor="middle" fill="#9aa6b5" font-size="10">LIVE — CURRENTLY RUNNING</text>
        </svg>
      </div>
    </div>

    <div class="panel"><strong>Favorites</strong><div class="sub">Favorite events selected on the Events tab appear here.</div><div id="favoriteGrid" class="favoriteGrid"></div></div>
    <div class="card"><strong class="small">Next scheduled event</strong><div id="nextEvent" class="sub" style="margin-top:4px">Loading…</div></div>
  </section>

  <section class="page" data-page="lights">
    <div class="panel">
      <div class="row between"><div><strong>Light Preview</strong><div id="previewName" class="sub">Current</div></div><div id="previewEffect" class="sub">Solid</div></div>
      <div class="card" style="margin-top:10px"><div id="ledRows" class="ledrows"></div></div>
    </div>
    <div class="panel">
      <strong>Build Your Lights</strong><div class="sub">Manual changes become the currently running light state.</div>
      <div class="label">Colors</div>
      <div class="sub">Build a one-color or multi-color RGBIC preset. Add up to 8 colors.</div>
      <div id="colorBuilder" class="colorBuilder"></div>
      <div class="colorActions">
        <button id="addColor" class="btn" type="button">+ Add Color</button>
        <button id="clearColors" class="btn" type="button">Reset to 1 Color</button>
      </div>
      <div class="label">Quick colors</div>
      <div class="quick" id="quickColors" style="margin-top:8px"></div>
      <div class="label">Effect</div><select id="effectSelect" class="field"><option>Solid</option><option>Fade</option><option>Pulse</option><option>Rainbow</option><option>Chase</option><option>Twinkle</option><option>Meteor</option><option>Candy Cane</option><option>Fire</option><option>Water</option></select>
      <div class="label row between"><span>Brightness</span><span id="brightVal" class="muted">75%</span></div><input id="brightness" type="range" min="1" max="100" value="75">
      <div class="label row between"><span>Speed</span><span id="speedVal" class="muted">Normal</span></div><input id="speed" type="range" min="1" max="5" value="3">
      <button id="savePreset" class="btn primary" style="width:100%;margin-top:12px">Save Current as Custom Preset</button>
    </div>
    <div class="panel"><strong>Presets</strong><div class="sub">Favorites are managed from Events, not here.</div><div id="presetList" class="presetList"></div></div>
  </section>

  <section class="page" data-page="events">
    <div class="panel">
      <div class="row between wraprow"><div><strong>Events This Month</strong><div class="sub">Enable schedules and mark Home favorites.</div></div><label class="row"><input id="eventsMaster" type="checkbox" checked><span class="small">Scheduler on</span></label></div>
      <div class="monthHead"><select id="monthSelect" class="field"></select><select id="yearSelect" class="field"></select></div>
      <div class="monthActions"><button id="enableMonth" class="btn">✓ Enable All</button><button id="clearMonth" class="btn">Clear Month</button></div>
      <div id="overlapInfo" class="note"></div><div id="eventList" style="display:grid;gap:8px;margin-top:10px"></div>
    </div>
  </section>

  <section class="page" data-page="wifi">
    <div class="panel">
      <strong>Device Wi-Fi</strong><div class="sub" style="margin-top:4px">Changes the Wi-Fi network the NanoC6 itself connects to.</div>
      <div class="card" style="margin-top:10px"><div class="small"><strong>Current connection</strong></div><div id="currentSsid" class="small" style="margin-top:4px">Not connected</div><div id="wifiMeta" class="sub">Signal: — • IP: —</div></div>
      <div class="label">Available networks</div><select id="wifiNetwork" class="field"><option>Tap Scan Again</option></select>
      <div class="label">Password</div><input id="wifiPassword" type="password" class="field" placeholder="Wi-Fi password">
      <button id="scanWifi" class="btn" style="width:100%;margin-top:10px">Scan Again</button><button id="saveWifi" class="btn primary" style="width:100%;margin-top:8px">Save & Reconnect Device</button>
    </div>
    <div class="card small"><strong>Recovery hotspot</strong><div class="sub" style="margin-top:4px">If the saved network cannot be reached, connect your phone to <b>AndersonHome-Setup</b>, password <b>andersonhome</b>, then open <b>192.168.4.1</b>.</div></div>
  </section>

  <section class="page" data-page="settings">
    <div class="panel">
      <strong>Overlap Behavior</strong><div class="sub">When two month-long events overlap</div>
      <div class="label">Mode</div><select id="overlapMode" class="field"><option value="rotate">Rotate nightly</option><option value="split">Split the night</option><option value="combine">Combine colors</option></select>
      <div id="overlapHelp" class="card small" style="margin-top:8px"></div>
    </div>
    <div class="panel">
      <strong>Scheduling Rules</strong>
      <div class="grid2" style="margin-top:10px"><div><div class="label">Lights ON</div><input id="onTime" type="time" value="17:00" class="field"></div><div><div class="label">Lights OFF</div><input id="offTime" type="time" value="23:00" class="field"></div></div>
      <div class="grid2"><div><div class="label">Holiday starts before</div><select id="leadDays" class="field"><option value="0">0 days</option><option value="1">1 day</option><option value="2" selected>2 days</option><option value="3">3 days</option><option value="5">5 days</option><option value="7">7 days</option></select></div><div><div class="label">Continues after</div><select id="trailDays" class="field"><option value="0" selected>0 days</option><option value="1">1 day</option><option value="2">2 days</option><option value="3">3 days</option></select></div></div>
      <div class="label">Time zone</div><select id="tz" class="field"><option value="EST5EDT,M3.2.0,M11.1.0" selected>Eastern Time — automatic DST</option><option value="CST6CDT,M3.2.0,M11.1.0">Central Time — automatic DST</option><option value="MST7MDT,M3.2.0,M11.1.0">Mountain Time — automatic DST</option><option value="PST8PDT,M3.2.0,M11.1.0">Pacific Time — automatic DST</option></select>
      <button id="saveSettings" class="btn primary" style="width:100%;margin-top:12px">Save Schedule Settings</button>
    </div>

    <div class="panel">
      <strong>Bluetooth Light Controller</strong><div class="sub">The NanoC6 scans for the existing LED BLE controller and bridges commands to it.</div>
      <div class="card" style="margin-top:10px"><div id="bleStatus" class="small">Not connected</div><div id="bleMeta" class="sub">Protocol: Auto</div></div>
      <div class="label">Protocol</div><select id="bleProtocol" class="field"><option value="0">Auto detect</option><option value="1">LEDBLE (7E…EF)</option><option value="2">RGBIC/SPI (7B…BF)</option><option value="3">RGBIC/SPI shifted</option></select>
      <button id="scanBle" class="btn" style="width:100%;margin-top:10px">Scan Bluetooth Controllers</button><div id="bleList" class="bleList"></div>
      <div class="grid2" style="margin-top:10px"><button id="testRed" class="btn">Test Red</button><button id="testRainbow" class="btn">Test Rainbow</button></div>
    </div>

    <div class="panel"><strong>Priority</strong><div class="sub" style="display:grid;gap:4px;margin-top:8px"><div>1. Manual override</div><div>2. Specific holiday / awareness day</div><div>3. Holiday window</div><div>4. Month-long events</div><div>5. Seasonal theme</div><div>6. Normal preset</div></div></div>
  </section>

  <div id="statusMsg" class="status" aria-live="polite"></div>
</div>
<script>
const API_MODE = location.protocol==='http:' || location.protocol==='https:';
const $=id=>document.getElementById(id); const status=m=>$('statusMsg').textContent=m;
async function api(path, opts={}){if(!API_MODE) throw new Error('preview'); const r=await fetch(path,opts); if(!r.ok) throw new Error(await r.text()||r.statusText); const t=await r.text(); return t?JSON.parse(t):{}}
async function post(path,obj){return api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)})}
document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===btn));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===btn.dataset.tab));if(btn.dataset.tab==='events')loadEvents();}));

const leds=[],rows=$('ledRows');{const row=document.createElement('div');row.className='ledgrid';for(let i=0;i<20;i++){const d=document.createElement('div');d.className='led';row.appendChild(d);leds.push(d)}rows.appendChild(row)}
const houseLeds=[],houseGroup=$('houseLeds'),pts=[[58,82],[72,76],[86,69],[100,62],[114,55],[128,49],[142,42],[156,35],[170,28],[184,28],[198,35],[212,42],[226,49],[240,55],[254,62],[268,69],[282,76],[300,82],[285,92],[285,106],[285,120],[285,134],[270,145],[250,145],[230,145],[210,145],[190,145],[170,145],[150,145],[130,145],[110,145],[90,145],[75,134],[75,118],[75,102],[75,88]];
pts.forEach(([x,y])=>{const c=document.createElementNS('http://www.w3.org/2000/svg','circle');c.setAttribute('cx',x);c.setAttribute('cy',y);c.setAttribute('r','5');c.setAttribute('class','houseLed');houseGroup.appendChild(c);houseLeds.push(c)});

let power=true,brightness=75,speed=3,tick=0;
let running={name:'Warm White',colors:['#fff1c7'],effect:'Solid'},preview={...running,colors:[...running.colors]};
function paint(state,i,br,total){let c=state.colors[i%state.colors.length]||'#25a7ff',a=br,s=1,e=state.effect;if(!power){c='#2a313b';a=.35}else if(e==='Rainbow')c=`hsl(${(i*8+tick*8)%360},95%,55%)`;else if(e==='Twinkle'){let z=Math.sin(i*12.99+Math.floor(tick)*78.2)*43758.5,sp=(z-Math.floor(z))>.86;c=sp?'#fff':state.colors[i%state.colors.length];a=sp?br:br*.22;s=sp?1.18:.9}else if(e==='Pulse')a=br*(.25+.75*((Math.sin(tick/2)+1)/2));else if(e==='Fade')a=br*(.35+.65*((Math.sin(tick/4)+1)/2));else if(e==='Chase'){let active=(i%7)===Math.floor(tick)%7;a=active?br:br*.12;s=active?1.18:.9}else if(e==='Meteor'){let head=Math.floor(tick*1.3)%total,dist=(head-i+total)%total;if(dist<10){a=br*(1-dist/11);c=dist<2?'#fff':state.colors[i%state.colors.length]}else a=.05}else if(e==='Candy Cane')c=(Math.floor((i+tick/3)/3)%2===0)?(state.colors[0]||'#d22'):(state.colors[1]||'#fff');else if(e==='Fire'){let f=.55+.45*Math.abs(Math.sin(i*.9+tick*2.5));c=`rgb(255,${Math.round(40+130*f)},0)`;a=br*f}else if(e==='Water'){let w=(Math.sin(i*.7+tick)+1)/2;c=`rgb(0,${Math.round(90+110*w)},255)`;a=br*(.45+.55*w)}return{c,a,s}}
function animate(){const rates=[0,.10,.22,.45,.82,1.35];tick+=rates[speed]||.45;const br=brightness/100;leds.forEach((el,i)=>{const x=paint(preview,i,br,leds.length);el.style.background=x.c;el.style.opacity=Math.max(.08,x.a);el.style.boxShadow=power?`0 0 ${Math.round(4+12*x.a)}px ${x.c}`:'none';el.style.transform=`scale(${x.s})`});houseLeds.forEach((el,i)=>{const x=paint(running,i,br,houseLeds.length);el.setAttribute('fill',x.c);el.setAttribute('opacity',Math.max(.12,x.a));el.style.filter=power?`drop-shadow(0 0 ${Math.round(2+7*x.a)}px ${x.c})`:'none'});requestAnimationFrame(animate)}requestAnimationFrame(animate);

function setRunning(name,colors,effect){
  running={name,colors:[...colors],effect};
  preview={name,colors:[...colors],effect};
  $('nowTheme').textContent=name;
  $('previewName').textContent=name;
  $('previewEffect').textContent=effect;
  $('effectSelect').value=effect;
  setBuilderColors(colors,false);
}
function setPreview(name,colors,effect){
  preview={name,colors:[...colors],effect};
  $('previewName').textContent=name;
  $('previewEffect').textContent=effect;
  $('effectSelect').value=effect;
  setBuilderColors(colors,false);
}
async function manual(obj){try{const s=await post('/api/control',obj);applyState(s);status('Manual override active.')}catch(e){if(!API_MODE){if(obj.power!==undefined)power=obj.power;if(obj.brightness!==undefined)brightness=obj.brightness;if(obj.speed!==undefined)speed=obj.speed;if(obj.colors)setRunning(obj.name||'Manual',obj.colors,obj.effect||'Solid');status('Preview mode — control simulated.')}else status('Control failed: '+e.message)}}

let builderColors=['#25a7ff'];

function setBuilderColors(colors, send=false){
  builderColors=(colors && colors.length ? colors.slice(0,8) : ['#25a7ff']);
  renderColorBuilder();
  if(send) sendBuilderLook();
}

function renderColorBuilder(){
  const box=$('colorBuilder');
  box.innerHTML='';
  builderColors.forEach((color,index)=>{
    const row=document.createElement('div');
    row.className='colorSlot';

    const picker=document.createElement('input');
    picker.type='color';
    picker.value=/^#[0-9a-f]{6}$/i.test(color)?color:'#25a7ff';
    picker.setAttribute('aria-label','Color '+(index+1));
    picker.addEventListener('input',e=>{
      builderColors[index]=e.target.value;
      preview={name:'Custom Multi-Color',colors:[...builderColors],effect:$('effectSelect').value};
    });
    picker.addEventListener('change',()=>sendBuilderLook());

    const label=document.createElement('div');
    label.className='slotName';
    label.textContent='Color '+(index+1);

    const move=document.createElement('button');
    move.type='button';
    move.className='btn moveBtn';
    move.textContent=index===0?'↓':'↑';
    move.title=index===0?'Move down':'Move up';
    move.disabled=builderColors.length<2;
    move.addEventListener('click',()=>{
      if(builderColors.length<2)return;
      const j=index===0?1:index-1;
      [builderColors[index],builderColors[j]]=[builderColors[j],builderColors[index]];
      renderColorBuilder();
      sendBuilderLook();
    });

    const remove=document.createElement('button');
    remove.type='button';
    remove.className='btn removeBtn';
    remove.textContent='×';
    remove.title='Remove color';
    remove.disabled=builderColors.length===1;
    remove.addEventListener('click',()=>{
      if(builderColors.length===1)return;
      builderColors.splice(index,1);
      renderColorBuilder();
      sendBuilderLook();
    });

    row.append(picker,label,move,remove);
    box.appendChild(row);
  });
  $('addColor').disabled=builderColors.length>=8;
}

function sendBuilderLook(){
  const fx=$('effectSelect').value;
  manual({name:builderColors.length>1?'Custom Multi-Color':'Custom Color',colors:[...builderColors],effect:fx});
}

$('addColor').addEventListener('click',()=>{
  if(builderColors.length>=8)return;
  const suggestions=['#ffffff','#ff3b30','#34c759','#0a84ff','#bf5af2','#ff9500','#ffd60a'];
  builderColors.push(suggestions[(builderColors.length-1)%suggestions.length]);
  renderColorBuilder();
  sendBuilderLook();
});
$('clearColors').addEventListener('click',()=>setBuilderColors([builderColors[0]||'#25a7ff'],true));

const quick=['#fff1c7','#ffffff','#ff3b30','#ff9500','#ffd60a','#34c759','#32d7d5','#0a84ff','#bf5af2','#ff2d92','#ff6b35','#00b4d8'];
quick.forEach(c=>{
  const b=document.createElement('button');
  b.className='swatch';
  b.style.background=c;
  b.type='button';
  b.title='Add '+c;
  b.addEventListener('click',()=>{
    if(builderColors.length===1 && builderColors[0]==='#25a7ff') builderColors[0]=c;
    else if(builderColors.length<8) builderColors.push(c);
    else builderColors[builderColors.length-1]=c;
    renderColorBuilder();
    sendBuilderLook();
  });
  $('quickColors').appendChild(b);
});
renderColorBuilder();$('effectSelect').addEventListener('change',e=>manual({name:builderColors.length>1?'Custom Multi-Color':'Manual '+e.target.value,colors:[...builderColors],effect:e.target.value}));
$('masterPower').addEventListener('change',e=>manual({power:e.target.checked}));$('brightness').addEventListener('input',e=>{$('brightVal').textContent=e.target.value+'%';$('homeBrightness').value=e.target.value;$('homeBrightVal').textContent=e.target.value+'%'});$('brightness').addEventListener('change',e=>manual({brightness:+e.target.value}));
$('homeBrightness').addEventListener('input',e=>{$('homeBrightVal').textContent=e.target.value+'%';$('brightness').value=e.target.value;$('brightVal').textContent=e.target.value+'%'});$('homeBrightness').addEventListener('change',e=>manual({brightness:+e.target.value}));
$('speed').addEventListener('input',e=>{$('speedVal').textContent=['Very Slow','Slow','Normal','Fast','Very Fast'][+e.target.value-1];speed=+e.target.value});$('speed').addEventListener('change',e=>manual({speed:+e.target.value}));

const presets=[['Warm White',['#fff1c7'],'Solid'],['Cool White',['#eef7ff'],'Solid'],['Red',['#ff3b30'],'Solid'],['Blue',['#0a84ff'],'Solid'],['Purple',['#bf5af2'],'Solid'],['Rainbow',['#25a7ff'],'Rainbow'],['Patriotic',['#ef4444','#ffffff','#2563eb'],'Chase'],['Christmas',['#dc2626','#16a34a','#ffffff'],'Candy Cane'],['Halloween',['#ff7a00','#7e22ce','#16a34a'],'Twinkle'],['Suicide Prevention',['#14b8a6','#7e22ce'],'Fade']];
presets.forEach(([n,c,e])=>{const row=document.createElement('div');row.className='card presetRow';const info=document.createElement('div');info.innerHTML=`<div class="small"><strong>${n}</strong></div><div class="sub">${e}</div><div class="chips">${c.map(x=>`<span class="chip" style="background:${x}"></span>`).join('')}</div>`;const b=document.createElement('button');b.className='btn presetApply';b.textContent='Apply';b.addEventListener('click',()=>manual({name:n,colors:c,effect:e}));row.append(info,b);$('presetList').appendChild(row)});

const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];const now=new Date();monthNames.forEach((m,i)=>{const o=new Option(m,i+1);if(i===now.getMonth())o.selected=true;$('monthSelect').add(o)});for(let y=now.getFullYear();y<=now.getFullYear()+10;y++)$('yearSelect').add(new Option(y,y));$('monthSelect').addEventListener('change',loadEvents);$('yearSelect').addEventListener('change',loadEvents);

const demoEvents={
9:[
{id:'labor',name:'Labor Day',when:'1st Monday in September',kind:'holiday',colors:['#ef4444','#ffffff','#2563eb'],effect:'Chase',enabled:true,favorite:false},
{id:'childcancer',name:'Childhood Cancer Awareness Month',when:'All September',kind:'awareness',colors:['#facc15','#f59e0b'],effect:'Twinkle',enabled:true,favorite:false},
{id:'suicide',name:'Suicide Prevention Awareness Month',when:'All September',kind:'awareness',colors:['#14b8a6','#7e22ce'],effect:'Fade',enabled:true,favorite:true},
{id:'988',name:'988 Day',when:'Sep 8',kind:'awareness',colors:['#14b8a6','#7e22ce','#ffffff'],effect:'Pulse',enabled:true,favorite:true},
{id:'wspd',name:'World Suicide Prevention Day',when:'Sep 10',kind:'awareness',colors:['#14b8a6','#7e22ce'],effect:'Fade',enabled:true,favorite:false},
{id:'patriot',name:'Patriot Day / 9-11 Remembrance',when:'Sep 11',kind:'holiday',colors:['#ef4444','#ffffff','#2563eb'],effect:'Solid',enabled:true,favorite:true}
]};

async function loadEvents(){let data;try{data=await api(`/api/events?year=${$('yearSelect').value}&month=${$('monthSelect').value}`)}catch(e){data={events:demoEvents[+$('monthSelect').value]||[],overlap:'Preview mode'};}renderEvents(data.events||[]);$('overlapInfo').textContent=data.overlap||'No overlapping month-long events.'}
function renderEvents(events){const list=$('eventList');list.innerHTML='';events.forEach(ev=>{const row=document.createElement('div');row.className='card event';const checks=document.createElement('div');checks.className='eventchecks';const en=document.createElement('input');en.type='checkbox';en.checked=ev.enabled;en.title='Scheduled';const fav=document.createElement('input');fav.type='checkbox';fav.checked=ev.favorite;fav.title='Favorite';checks.append(en,fav);const main=document.createElement('div');main.innerHTML=`<div class="small"><strong>${ev.name}</strong></div><div class="sub">${ev.when} • ${ev.effect}</div><div class="sub" style="margin-top:4px">Top box = scheduled • Bottom box = ★ favorite</div><div class="tags"><span class="tag ${ev.kind}">${ev.kind}</span></div><div class="chips">${ev.colors.map(c=>`<span class="chip" style="background:${c}"></span>`).join('')}</div>`;const pv=document.createElement('button');pv.className='btn previewEvent';pv.textContent='Preview';pv.addEventListener('click',()=>{setPreview(ev.name,ev.colors,ev.effect);status(ev.name+' loaded in preview only.')});en.addEventListener('change',()=>eventChange(ev.id,{enabled:en.checked}));fav.addEventListener('change',()=>eventChange(ev.id,{favorite:fav.checked}));row.append(checks,main,pv);list.appendChild(row)})}
async function eventChange(id,change){try{await post('/api/event',{id,...change});await Promise.all([loadEvents(),loadFavorites()]);status('Event preference saved.')}catch(e){status(API_MODE?'Save failed: '+e.message:'Preview mode — preference simulated.')}}
$('enableMonth').addEventListener('click',()=>post('/api/events/bulk',{year:+$('yearSelect').value,month:+$('monthSelect').value,enabled:true}).then(loadEvents).catch(()=>status('Preview mode.')));
$('clearMonth').addEventListener('click',()=>post('/api/events/bulk',{year:+$('yearSelect').value,month:+$('monthSelect').value,enabled:false}).then(loadEvents).catch(()=>status('Preview mode.')));

async function loadFavorites(){let favs=[];try{favs=(await api('/api/favorites')).events||[]}catch(e){favs=(demoEvents[9]||[]).filter(x=>x.favorite)}const grid=$('favoriteGrid');grid.innerHTML='';if(!favs.length){grid.innerHTML='<div class="emptyFav" style="grid-column:1/-1">No favorites selected. Mark ★ favorites on the Events tab.</div>';return}favs.forEach(ev=>{const b=document.createElement('button');b.className='btn';b.textContent=ev.name;b.addEventListener('click',()=>manual({name:ev.name,colors:ev.colors,effect:ev.effect}));grid.appendChild(b)})}

function applyState(s){if(!s)return;power=s.power??power;brightness=s.brightness??brightness;speed=s.speed??speed;$('masterPower').checked=power;$('brightness').value=brightness;$('homeBrightness').value=brightness;$('brightVal').textContent=brightness+'%';$('homeBrightVal').textContent=brightness+'%';$('speed').value=speed;$('speedVal').textContent=['Very Slow','Slow','Normal','Fast','Very Fast'][speed-1]||'Normal';if(s.running)setRunning(s.running.name,s.running.colors,s.running.effect);$('scheduleWindow').textContent=s.scheduleWindow||$('scheduleWindow').textContent;$('nextEvent').textContent=s.nextEvent||'—';if(s.wifi){$('currentSsid').textContent=s.wifi.ssid||'Not connected';$('wifiMeta').textContent=`Signal: ${s.wifi.rssi??'—'} dBm • IP: ${s.wifi.ip||'—'}`}$('bleStatus').textContent=s.ble?.connected?`Connected: ${s.ble.name||s.ble.address}`:'Not connected';$('bleMeta').textContent=`Protocol: ${s.ble?.protocol||'Auto'}`;}
async function loadState(){try{const s=await api('/api/state');$('connectionBadge').textContent='● Connected';$('connectionBadge').classList.remove('offline');applyState(s);loadFavorites()}catch(e){$('connectionBadge').textContent='● Preview';$('connectionBadge').classList.add('offline');setRunning('Suicide Prevention Awareness Month',['#14b8a6','#7e22ce'],'Fade');$('nextEvent').textContent='988 Day • September 8';loadFavorites()}}
$('resumeSchedule').addEventListener('click',()=>post('/api/resume',{}).then(s=>{applyState(s);status('Automatic schedule resumed.')}).catch(()=>status('Preview mode — schedule resumed.')));

function overlapHelp(){const v=$('overlapMode').value;$('overlapHelp').textContent=v==='rotate'?'Each enabled monthly event gets a full night, then the next one runs the following night.':v==='split'?'The scheduled night is divided evenly among enabled month-long events.':'Colors from all enabled month-long events are combined into one theme.'}$('overlapMode').addEventListener('change',overlapHelp);overlapHelp();
$('saveSettings').addEventListener('click',async()=>{const o={overlap:$('overlapMode').value,on:$('onTime').value,off:$('offTime').value,lead:+$('leadDays').value,trail:+$('trailDays').value,tz:$('tz').value,bleProtocol:+$('bleProtocol').value,scheduler:$('eventsMaster').checked};try{await post('/api/settings',o);status('Settings saved.')}catch(e){status(API_MODE?'Settings failed: '+e.message:'Preview mode — settings simulated.')}});
$('eventsMaster').addEventListener('change',()=>post('/api/settings',{scheduler:$('eventsMaster').checked}).catch(()=>{}));

$('scanWifi').addEventListener('click',async()=>{status('Scanning Wi-Fi…');try{const r=await api('/api/wifi/scan');const sel=$('wifiNetwork');sel.innerHTML='';(r.networks||[]).forEach(n=>sel.add(new Option(`${n.ssid} (${n.rssi} dBm)`,n.ssid)));status(`${(r.networks||[]).length} networks found.`)}catch(e){status(API_MODE?'Wi-Fi scan failed.':'Preview mode — Wi-Fi scanning requires the NanoC6.')}});
$('saveWifi').addEventListener('click',async()=>{const ssid=$('wifiNetwork').value,p=$('wifiPassword').value;if(!ssid)return status('Select a network first.');try{await post('/api/wifi',{ssid,password:p});status('Wi-Fi saved. The NanoC6 is reconnecting…')}catch(e){status(API_MODE?'Wi-Fi save failed.':'Preview mode.')}});
$('scanBle').addEventListener('click',async()=>{status('Scanning Bluetooth…');try{const r=await api('/api/ble/scan');const box=$('bleList');box.innerHTML='';(r.devices||[]).forEach(d=>{const row=document.createElement('div');row.className='card bleDevice';row.innerHTML=`<div><div class="small"><strong>${d.name||'BLE controller'}</strong></div><div class="sub">${d.address} • ${d.rssi} dBm</div></div>`;const b=document.createElement('button');b.className='btn';b.textContent='Use';b.addEventListener('click',()=>post('/api/ble/select',{address:d.address,protocol:+$('bleProtocol').value}).then(loadState));row.appendChild(b);box.appendChild(row)});status(`${(r.devices||[]).length} controllers found.`)}catch(e){status(API_MODE?'Bluetooth scan failed.':'Preview mode — BLE scanning requires the NanoC6.')}});
$('testRed').addEventListener('click',()=>manual({name:'BLE Test Red',colors:['#ff0000'],effect:'Solid'}));$('testRainbow').addEventListener('click',()=>manual({name:'BLE Test Rainbow',colors:['#25a7ff'],effect:'Rainbow'}));
$('savePreset').addEventListener('click',async()=>{
  const preset={name:'Custom '+new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),colors:[...builderColors],effect:$('effectSelect').value};
  try{
    await post('/api/preset',preset);
    status('Multi-color preset saved to the NanoC6.');
  }catch(e){
    const saved=JSON.parse(localStorage.getItem('andersonCustomPresets')||'[]');
    saved.push(preset);
    localStorage.setItem('andersonCustomPresets',JSON.stringify(saved.slice(-12)));
    status(API_MODE?'Preset save failed: '+e.message:'Preview mode — multi-color preset saved on this phone.');
  }
});

loadState();loadEvents();setInterval(()=>{if(API_MODE)loadState()},15000);
</script>
</body></html>
)ANDERSONHTML";
