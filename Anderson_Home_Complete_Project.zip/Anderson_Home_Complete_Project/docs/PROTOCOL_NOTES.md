# BLE Protocol Notes

Target GATT:
- Service: `0000FFE0-0000-1000-8000-00805F9B34FB`
- Write characteristic: `0000FFE1-0000-1000-8000-00805F9B34FB`

LEDBLE profile examples:
- Power on: `7E FF 04 01 FF FF FF FF EF`
- Power off: `7E FF 04 00 FF FF FF FF EF`
- Static RGB: `7E FF 05 03 R G B FF EF`
- Brightness: `7E FF 01 B 00 FF FF FF EF`
- Speed: `7E FF 02 S 00 FF FF FF EF`
- Mode: `7E FF 03 M 03 FF FF FF EF`

RGBIC/SPI profiles use the `7B ... BF` framing; shifted variants are also supported in the firmware.

The real controller's exact advertised name and mode table must be confirmed during commissioning.
