# Commissioning Checklist

- [ ] NanoC6 powers and serial log starts
- [ ] AndersonHome-Setup AP appears if home Wi-Fi is unavailable
- [ ] Device connects to chosen 2.4 GHz Wi-Fi
- [ ] `anderson-home.local` opens
- [ ] Home mini-house animates current running theme
- [ ] Lights speed slider visibly changes preview speed
- [ ] Event schedule checkboxes save after reboot
- [ ] Event favorite checkboxes populate Home
- [ ] Monthly overlap rotation works
- [ ] BLE scan finds the light controller
- [ ] Test Red changes real lights red
- [ ] Brightness changes real lights
- [ ] Test Rainbow runs a moving effect
- [ ] Power off/on works
- [ ] Resume Schedule restores automatic theme
- [ ] Long-hold NanoC6 button (~5 sec) clears Wi-Fi and starts recovery setup after restart
- [ ] Android app opens controller without typing the address
