# Anderson Home — Project Progress

## Current Web Interface Baseline
Master preview: `Anderson_Home_Web_Interface_MASTER.html`

### Navigation
- Home
- Lights
- Events
- Wi-Fi
- Settings

### Home
- Anderson Home branding
- Master power
- Brightness control
- "Running Tonight" status
- Animated mini-house tied to the currently running light state
- Home favorites populated from favorite selections made in the Events tab
- Next scheduled event card
- Resume Schedule control

### Lights
- Single-row animated light preview
- Color picker
- Quick colors
- Effects:
  - Solid
  - Fade
  - Pulse
  - Rainbow
  - Chase
  - Twinkle
  - Meteor
  - Candy Cane
  - Fire
  - Water
- Brightness control
- Effect speed control
  - Very Slow
  - Slow
  - Normal
  - Fast
  - Very Fast
- Speed control now changes the actual animation timing
- Save as Preset
- Presets can be applied here, but favorites are NOT selected here

### Events
- Monthly event list instead of a large calendar
- Schedule enable checkbox for each event
- Separate favorite checkbox for each event
- Event favorites appear on Home
- Event preview does not falsely change the currently running Home state
- Monthly overlap handling is supported

### Wi-Fi
- Dedicated Device Wi-Fi tab
- Intended to change the Wi-Fi network used by the NanoC6 itself
- Network scan/select
- Password entry
- Save & reconnect
- Planned fallback setup hotspot if saved Wi-Fi is unavailable

### Settings
- Overlap behavior:
  - Rotate nightly
  - Split the night
  - Combine colors
- Scheduling rules
- On/off times
- Holiday lead time
- Time zone
- Priority hierarchy

## Scheduling / Event Design Decisions
- Specific holiday / awareness day overrides monthly themes
- Holiday windows override monthly themes
- Multiple month-long events can rotate nightly by default
- Seasonal November/December themes are lower priority
- Floating holidays will be calculated automatically each year
- Mardi Gras derives from Easter
- Hanukkah will be dynamically dated and run for 8 nights
- Major U.S. holidays, high-profile observances, and selected public-awareness events are included
- Daily entries from the reference screenshot are intentionally excluded

## Current Priority Logic
1. Manual override
2. Specific holiday / awareness day
3. Holiday window
4. Month-long events
5. Seasonal theme
6. Normal preset

## Planned Hardware / Firmware Target
- M5Stack NanoC6 / ESP32-C6
- NanoC6 serves the web interface
- Web UI and controller logic kept as one maintainable interface
- BLE bridge layer will send commands to the CETELUMA light controller
- Wi-Fi settings stored on-device so network changes do not require reflashing
- Recovery AP / setup hotspot planned

## Planned Android App
After the web interface is finished:
- Lightweight Android wrapper
- Opens directly to Anderson Home controller
- Auto-reconnect / controller discovery
- No browser address typing
- Reuses the same UI served by the NanoC6

## Next Recommended Step
Integrate the complete event/holiday/awareness library and scheduling engine into the current tabbed MASTER interface, then convert that completed UI into the ESP32-C6 firmware web assets and begin wiring the real command layer.
