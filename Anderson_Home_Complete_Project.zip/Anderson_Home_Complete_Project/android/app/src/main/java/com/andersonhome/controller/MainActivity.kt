package com.andersonhome.controller

import android.graphics.Bitmap
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var nsd: NsdManager
    private var discovering = false
    private var mainFrameLoadFailed = false

    private val defaultUrl = "http://anderson-home.local/"
    private val setupUrl = "http://192.168.4.1/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        status = findViewById(R.id.status)
        nsd = getSystemService(NSD_SERVICE) as NsdManager

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                mainFrameLoadFailed = false
                status.text = if (isSetupUrl(url)) "Opening setup…" else "Connecting…"
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    mainFrameLoadFailed = true

                    if (isSetupUrl(request.url?.toString())) {
                        status.text = "Setup unavailable — join AndersonHome-Setup Wi-Fi"
                    } else {
                        status.text = "Controller not found — discovering…"
                        discover()
                    }
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                // WebView can call onPageFinished for its own error page.
                // Never report "Connected" after a failed main-frame load.
                if (mainFrameLoadFailed || url.isNullOrBlank()) return

                if (isSetupUrl(url)) {
                    status.text = "Setup mode"
                    return
                }

                status.text = "Connected"

                // Do not save the recovery/setup address as the normal controller URL.
                if (isControllerUrl(url)) {
                    getPreferences(MODE_PRIVATE)
                        .edit()
                        .putString("url", url)
                        .apply()
                }
            }
        }

        findViewById<Button>(R.id.retry).setOnClickListener { connect() }

        findViewById<Button>(R.id.setup).setOnClickListener {
            status.text = "Opening setup…"
            web.loadUrl(setupUrl)
        }

        connect()
    }

    private fun connect() {
        mainFrameLoadFailed = false
        status.text = "Connecting…"
        val saved = getPreferences(MODE_PRIVATE).getString("url", defaultUrl) ?: defaultUrl
        web.loadUrl(saved)
    }

    private fun isSetupUrl(url: String?): Boolean {
        return try {
            Uri.parse(url ?: "").host == "192.168.4.1"
        } catch (_: Exception) {
            false
        }
    }

    private fun isControllerUrl(url: String): Boolean {
        return try {
            val host = Uri.parse(url).host ?: return false
            if (host.equals("anderson-home.local", ignoreCase = true)) return true
            if (host == "192.168.4.1") return false

            // Accept private-LAN IP addresses discovered through NSD.
            if (host.startsWith("10.")) return true
            if (host.startsWith("192.168.")) return true
            if (host.startsWith("172.")) {
                val second = host.split(".").getOrNull(1)?.toIntOrNull() ?: return false
                return second in 16..31
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun discover() {
        if (discovering) return
        discovering = true

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String?) {}

            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceName.contains("Anderson", true)) {
                    nsd.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}

                        override fun onServiceResolved(info: NsdServiceInfo) {
                            val host = info.host.hostAddress ?: return
                            runOnUiThread {
                                status.text = "Controller found"
                                web.loadUrl("http://$host:${info.port}/")
                            }
                        }
                    })
                }
            }

            override fun onServiceLost(service: NsdServiceInfo?) {}
            override fun onDiscoveryStopped(serviceType: String?) { discovering = false }
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) { discovering = false }
            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) { discovering = false }
        }

        try {
            nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
            discovering = false
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
