package com.andersonhome.controller

import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var nsd: NsdManager
    private var discovering = false
    private val defaultUrl = "http://anderson-home.local/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        status = findViewById(R.id.status)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { status.text = "Connected"; url?.let { getPreferences(MODE_PRIVATE).edit().putString("url", it).apply() } }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) { status.text = "Controller not found — discovering…"; discover() }
            }
        }
        findViewById<Button>(R.id.retry).setOnClickListener { connect() }
        findViewById<Button>(R.id.setup).setOnClickListener { web.loadUrl("http://192.168.4.1/") }
        connect()
    }

    private fun connect() {
        status.text = "Connecting…"
        val saved = getPreferences(MODE_PRIVATE).getString("url", defaultUrl) ?: defaultUrl
        web.loadUrl(saved)
    }

    private fun discover() {
        if (discovering) return
        discovering = true
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String?) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceName.contains("Anderson", true)) {
                    nsd.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {}
                        override fun onServiceResolved(info: NsdServiceInfo) {
                            val host = info.host.hostAddress ?: return
                            runOnUiThread {
                                status.text = "Controller found"
                                web.loadUrl("http://$host:${info.port}/")
                            }
                        }
                    })
                }
            }
            override fun onServiceLost(service: NsdServiceInfo?) {}
            override fun onDiscoveryStopped(serviceType: String?) { discovering = false }
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) { discovering = false }
            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) { discovering = false }
        }
        try { nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) { discovering = false }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}