plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.andersonhome.controller"
    compileSdk = 35
    defaultConfig { applicationId = "com.andersonhome.controller"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.1" }
    buildFeatures { viewBinding = false }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.google.android.material:material:1.12.0") }
